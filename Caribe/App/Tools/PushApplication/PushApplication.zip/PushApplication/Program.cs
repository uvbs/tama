﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Reflection;
using System.Net.Json;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Timers;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using INI;

namespace PushApplication
{    
    class Program
    {
        private const string DEVICE_ID = "";
        private string strUri = "https://android.googleapis.com/gcm/send";            //google url

        private string DBIp = "";
        private string DBName = "";
        private string DBId = "";
        private string DBPass = "";

        private string API_KEY = "AIzaSyCSr8aUCvk-Qij0NBRrBKGLfizpGSzBtWw";

        private const int APPLY_COUNT = 1000;
        private int PUSH_RATE = 5;
        
        Thread[] aThread;

        private struct PUSHMSGInfo
        {
            public Int64 index;
            public string deviceid;
            public string type;
            public string pushmessage;
        };
        
        private List<string> DeviceIDList;
        private List<PUSHMSGInfo> PushMSGList;


        public Int64 lasttmpIndex = 0;
        public Int64 lasttmpcount = 10000;


        static void Main(string[] args)
        {
            Program App = new Program();

            App.Run();
        }

        private void Run()
        {
            int n = 0;
            while (n == 0)
            {
                DoLoadDeviceID();
                DoLoadBookedPushMSG();
                DoProcessBookedPUSHMSG();
            }
                
                //Thread[] aThread = {
                //                   new Thread( new ThreadStart(DoLoadDeviceID)), 
                //                   new Thread( new ThreadStart(DoLoadBookedPushMSG))
                //               };

                //foreach (Thread t in aThread)
                //{
                //    t.Start();
                //}

                //Thread.Sleep(5000);
                ////aThread[1].Interrupt();
          //  }
            
        }
        private void DoLoadDeviceID()
        {
            Console.WriteLine("DeviceIDLoad Start");            
            Random r = new Random();
            lasttmpcount +=  r.Next(1, 100);

            for (int n = 0; n < lasttmpcount ; n++)
            {
                if (this.DeviceIDList == null)
                    this.DeviceIDList = new List<string>();
                string deviceid = CreateTempString();
                DeviceIDList.Add(deviceid);
            }
            Console.WriteLine("DeviceIDLoad Complete");
        }

        private static object Lock = new object();
        private void DoLoadBookedPushMSG()
        {
            Console.WriteLine("BookedPushMSGLoad Start");
            
            if (this.PushMSGList == null)
                this.PushMSGList = new List<PUSHMSGInfo>();

            PushMSGList.Clear();

            Random r = new Random();
            int i = r.Next(100, 150);
            for (int n = 0; n < i; n ++  )
            {
                lasttmpIndex++;
                PUSHMSGInfo Data = new PUSHMSGInfo();
                Data.index = lasttmpIndex;
                string message;
                
                message = CreateTempString();
                
                Data.deviceid = message;
                Data.type = r.Next(1, 3).ToString();
                Data.pushmessage = message;

                PushMSGList.Add(Data);
            }
            Console.WriteLine("PushMSGListSize:" + PushMSGList.Count);
            Console.WriteLine("BookedPushMSGLoad Complete");

            TaskCreationOptions option = TaskCreationOptions.None;
            //option = TaskCreationOptions.PreferFairness;
            //option = TaskCreationOptions.LongRunning;       // 작업이 장기 실행되는 정교하지 않은 작업이 되도록 지정합니다.초과 구독을 보장할 수 있는 TaskScheduler에 대한 힌트를 제공합니다.
            //option = TaskCreationOptions.AttachedToParent;  // 작업이 작업 계층 구조의 부모에 연결되도록 지정합니다.
            //option = TaskCreationOptions.DenyChildAttach;   // 지정 하는 InvalidOperationException 만들어진된 작업에는 자식 작업을 첨부 하려고 시도 하는 경우에 throw 됩니다.
            //option = TaskCreationOptions.HideScheduler;     // 앰비언트 스케줄러를 현재 스케줄러에서 만들어진된 작업으로 표시 되지 않습니다.즉, StartNew 또는 Continuewith와 같은 생성된 작업을 수행 하는 작업을 볼 수 있도록 Default 현재 스케줄러로 합니다.
        }
        public string CreateTempString()
        {
            string password = string.Empty;
            string[] alpabet = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "x", "y", "z" };
            string[] number = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            string[] special = { "!", "@", "#", "$", "%", "^", "&", "*" };

            lock (Lock)
            {
                Random nalpabet = new Random();
                Random nnumber = new Random();
                Random nspecial = new Random();

                password = alpabet[nalpabet.Next(0, 24)] + alpabet[nalpabet.Next(0, 24)] + alpabet[nalpabet.Next(0, 24)]
                           + number[nnumber.Next(0, 9)] + number[nnumber.Next(0, 9)] + number[nnumber.Next(0, 9)]
                           + special[nspecial.Next(0, 7)] + special[nspecial.Next(0, 7)];
            }
            
            return password;
        }
        
        //public Thread StartTheThread( String Message )
        //{
        //    Random r = new Random();
        //    int n = r.Next(10, 50);

        //    Thread t = new Thread(() => SendMessage(n, Message));
        //    t.Start();            
        //    return t;
        //}

        private List<Task> tasks = new List<Task>();
        private CancellationTokenSource cancellationTokenSource;
        private void ThreadPoolInitialization()
        {
            Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    //Min thread work
                    int minWorker, minIOC;
                    ThreadPool.GetMinThreads(out minWorker, out minIOC);

                    Console.WriteLine("minWorker{0}, minIOC{1}", minWorker, minIOC);
                    //Max thread work
                    int maxWorker, maxIOC;
                    ThreadPool.GetMaxThreads(out maxWorker, out maxIOC);
                    Console.WriteLine("maxWorker{0}, maxIOC{1}", maxWorker, maxIOC);

                  //  ThreadPool.SetMinThreads(minWorker, minIOC);

                    // 특정 시간에 스레드 풀에 있는 실제 스레드 수를 확인
                    int availableWorkThreads, availableCompletionPortThreads;
                    ThreadPool.GetAvailableThreads(out availableWorkThreads, out availableCompletionPortThreads);

                   // ThreadPool.SetMaxThreads(maxWorker, maxIOC);

                    Thread.Sleep(1000);
                }
            });

            // Radio가 선택이 되어 있을 때만 동작 하도록 하고 한번 선택이 되면 계속 실행 되도록 한다.
            // 한번 세팅되면 계속 유지 되기에 이전으로 되돌릴 수 없으며 가장 처음의 초기화 값으로 변경하는 로직으로 수정하면 될 것이다.
            //int minWorker, minIOC;

            //minWorker = int.Parse(txtMinWorkerCount.Text);
            //minIOC = int.Parse(txtMinWorkerIOCCount.Text);

            //// 스레드 작성 및 소멸을 관리하기 위한 알고리즘으로 전환하기 전에 새 요청에 따라 스레드 풀이 생성하는 스레드의 최소 수를 설정합니다.
            //// minWorker : 스레드 풀에서 필요할 때 만드는 작업자 I/O 스레드의 최소 개수입니다. 
            //// minIOC : 스레드 풀에서 필요할 때 만드는 비동기 I/O 스레드의 최소 개수입니다. File.BeginWrite(,,,) 와 같이 파일 관련 비동기 함수를 실해할 때 MinIOC를 쓰레드에서 실행한다. // http://msdn.microsoft.com/ko-kr/library/system.threading.threadpool.getmaxthreads.aspx﻿﻿ 확인 가능
            //ThreadPool.SetMinThreads(minWorker, minIOC);

            //int maxWorker, maxIOC;
            //maxWorker = int.Parse(txtMaxWorkerCount.Text);
            //maxIOC = int.Parse(txtMaxWorkerIOCCount.Text);
            //// 동시에 활성 상태가 될 수 있는 스레드 풀에 대한 요청 수를 설정합니다. 해당 수를 넘는 모든 요청은 스레드 풀 스레드가 사용 가능해질 때까지 큐에 대기 상태로 남아 있습니다.
            //// maxWorker : 스레드 풀에 있는 최대 작업자 스레드 수입니다. 
            //// minIOC : 스레드 풀에서 필요할 때 만드는 비동기 I/O 스레드의 최소 개수입니다. File.BeginWrite(,,,) 와 같이 파일 관련 비동기 함수를 실해할 때 MinIOC를 쓰레드에서 실행한다. // http://msdn.microsoft.com/ko-kr/library/system.threading.threadpool.getmaxthreads.aspx﻿﻿ 확인 가능
            //ThreadPool.SetMaxThreads(maxWorker, maxIOC);
            
        }
        private void DoProcessBookedPUSHMSG()
        {
            try
            {
                //ThreadPoolInitialization();

                //시작 시간 남기기.
                Console.WriteLine("DoProcessBookedPUSHMSG Start");
                DateTime currTime = DateTime.Now;
                Console.WriteLine("Start " + currTime.ToString("HH:mm:ss"));

                tasks = new List<Task>();
                int index = 0;
                foreach (PUSHMSGInfo p in PushMSGList)
                {
                    tasks.Add(Task.Factory.StartNew(() =>
                    {
                        lock (Lock)
                        {
                            index++;
                        }
                        SendMessage("[Make" + currTime.ToString("HH:mm:ss") + " [" + index + "] " + p.pushmessage);
                        
                    }));
                }
                Task.WaitAll(tasks.ToArray());

                //Task.Factory.StartNew(() =>
                //{

                //    // Task를 활성화 시킴
                //    tasks.ForEach(task => task.Start());

                //    // 모두 완료가 될때까지 대기
                //    Task.WaitAll(tasks.ToArray());

                //    // 모든 Task가 수행을 마쳐 더 이상 관리가 필요 없어져서 관리에서 제거
                //    tasks.Clear();
                //});           
                
                // Wait for all threads in pool to calculate.                
                Console.WriteLine("All calculations are complete.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString() + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }

            //3 //WaitHandle 을 사용하여 모두 기다리는 형태로..n개...
            //try
            //{
            //    //시작 시간 남기기.
            //    Console.WriteLine("DoProcessBookedPUSHMSG Start");
            //    DateTime currTime = DateTime.Now;
            //    Console.WriteLine("Start " + currTime.ToString("HH:mm:ss"));

            //    int PushMsgCount = PushMSGList.Count;
            //    // One event is used for each Fibonacci object.

            //    int outMax, outAble;
            //    ThreadPool.GetMaxThreads(out outMax, outAble);

            //    const int threadcount = 64;

            //    // Configure and start threads using ThreadPool.
            //    Console.WriteLine("launching {0} tasks...", PushMsgCount);

            //    int i = 0;
            //    while (PushMSGList.Count > i)
            //    {
            //        int eventcount = threadcount;
            //        if ((PushMSGList.Count - i) / threadcount == 0)
            //            eventcount = (PushMSGList.Count - i) % threadcount;
            //        ManualResetEvent[] doneEvents = new ManualResetEvent[eventcount];

            //        for (int theadindex = 0; theadindex < threadcount; theadindex++)
            //        {
            //            if (i == PushMsgCount)
            //                break;
             
            //            doneEvents[theadindex] = new ManualResetEvent(false);
            //            Sender f = new Sender(PushMSGList[i].deviceid, PushMSGList[i].pushmessage, doneEvents[theadindex]);
            //            ThreadPool.QueueUserWorkItem(f.ThreadPoolCallback, theadindex);
            //            i++;
            //            Console.WriteLine(i.ToString());             
            //        }
            //        WaitHandle.WaitAll(doneEvents);
            //        Console.WriteLine("#########################################################################################");
            //    }
                    

            //    // Wait for all threads in pool to calculate.                
            //    Console.WriteLine("All calculations are complete.");    
            //}
            //catch( Exception ex)
            //{
            //    Console.WriteLine(ex.ToString() + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //}
                  
            

            //2
            //int n = 0;            
            //if( PushMSGList.Count > 0 )
            //{
            //    Console.WriteLine("DoProcessBookedPUSHMSG Start");                
            //    DateTime currTime = DateTime.Now;
            //    Console.WriteLine("Start " + currTime.ToString("HH:mm:ss"));


            //    Thread[] aThread = new Thread[PushMSGList.Count];
            //    foreach (PUSHMSGInfo each in PushMSGList)
            //    {
            //        aThread[n] = StartTheThread(n.ToString() +" " + each.pushmessage);
            //        // aThread[n] = new Thread(new ParameterizedThreadStart(SendMessage));
            //        // aThread[n].Start(n.ToString() + each.pushmessage);
            //        n++;
            //        //SendMessage(each.pushmessage);
            //    }

            //    foreach (Thread t in aThread)
            //    {
            //        t.Join();
            //    }
            //    currTime = DateTime.Now;
            //    Console.WriteLine("End " + currTime.ToString("HH:mm:ss"));
            //    Console.WriteLine("DoProcessBookedPUSHMSG Complete");
            //    Console.WriteLine("모든 쓰레드가 종료 되었습니다.");                
            //}
            

            //1
            //aThread
            //Thread[] aThread = {
            //                       new Thread( new ThreadStart(DoLoadDeviceID)), 
            //                       new Thread( new ThreadStart(DoLoadBookedPushMSG)),
            //                       new Thread( new ThreadStart(DoProcessBookedPUSHMSG)
            //                   };

            //foreach (Thread t in aThread)
            //{
            //    t.Start();
            //}

            //Thread.Sleep(5);
            //aThread[1].Interrupt();

            //foreach (Thread t in aThread)
            //{
            //    t.Join(100);
            //}
            //Console.WriteLine("모든 쓰레드가 종료 되었습니다.");
        }
        //public static void SendMessage(string message)
        //{            
        //    Console.WriteLine(message + " Send!!");
        //}        
        private void push_Elapsed(object sender, ElapsedEventArgs e)
        {
            //DB 에 처리 해야 하는Push가 있는지 확인 해 보고.
            LoadBookedPushMSG();
            ProcessBookedPUSHMSG();
        }
        private void LoadIniFilePath()
        {
            
            FileInfo exefileinfo = new FileInfo(System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]));
            string path = exefileinfo.Directory.FullName.ToString();  //프로그램 실행되고 있는데 path 가져오기
            string fileName = @"\Config.ini";  //파일명

            iniUtil ini = new iniUtil(path + fileName);   // 만들어 놓았던 iniUtil 객체 생성(생성자 인자로 파일경로 정보 넘겨줌)

            string DBIP = ini.GetIniValue("PUSHDB", "IP");
            string DBNAME = ini.GetIniValue("PUSHDB", "DBNAME");
            string DBID = ini.GetIniValue("PUSHDB", "ID");
            string DBPASS = ini.GetIniValue("PUSHDB", "PASS");

            string apikey = ini.GetIniValue("GCMN", "API_KEY");

            int pushterm = Convert.ToInt32(ini.GetIniValue("GCMN", "PUSH_RATE"));

            if (DBIP.Length > 0) DBIp = DBIP;
            if (DBNAME.Length > 0) DBName = DBIP;
            if (DBID.Length > 0) DBId = DBIP;
            if (DBPASS.Length > 0) DBPass = DBIP;
            if (apikey.Length > 0) API_KEY = apikey;
            if (pushterm > 0) PUSH_RATE = pushterm;
        }
        private bool LoadDeviceIDDB()
        {
            string UserIndex = string.Empty;
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = string.Format("Server={0};DataBase={1};Uid={2};Pwd={3}", this.DBIp, this.DBName, this.DBId, this.DBPass);
                    string sqlquery = "SELECT deviceid FROM  dbo.devicceidtable WHERE dbo.devicceidtable.status = 1 AND  dbo.devicceidtable.appstore = 'google' ORDERBY  index DESC";

                    SqlCommand cmd = new SqlCommand(sqlquery, con);
                    con.Open();

                    if (this.DeviceIDList == null)
                        this.DeviceIDList = new List<string>();

                    SqlDataReader rd = cmd.ExecuteReader();

                    while (rd.Read())
                    {
                        string deviceid = rd["deviceid"].ToString();
                        DeviceIDList.Add(deviceid);
                    }
                    rd.Close();
                    con.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine ( "[ERROR] " + ex.Message );
            }
            return false;
        }
        private void LoadBookedPushMSG()
        {
            if (DeviceIDList == null)
                DeviceIDList = new List<string>();
            else
                DeviceIDList.Clear();

            string UserIndex = string.Empty;
            try
            {
                if (this.PushMSGList == null)
                    this.PushMSGList = new List<PUSHMSGInfo>();

                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = string.Format("Server={0};DataBase={1};Uid={2};Pwd={3}", this.DBIp, this.DBName, this.DBId, this.DBPass);
                    string sqlquery = "SELECT index, pushmesssage, type, deviceid FROM dbo.pushmessagetable WHERE dbo.pushmessagetable.senddate  < GETDATE() ORDERBY  dbo.pushmessagetable.senddate DESC";

                    SqlCommand cmd = new SqlCommand(sqlquery, con);
                    con.Open();

                    SqlDataReader rd = cmd.ExecuteReader();
                    while (rd.Read())
                    {
                        PUSHMSGInfo Data = new PUSHMSGInfo();
                        string index = rd["index"].ToString();
                        if (Convert.ToInt64(index) > 0)
                        {
                            Data.index = Convert.ToInt64(index);
                            Data.deviceid = rd["deviceid"].ToString();
                            Data.type = rd["type"].ToString();
                            Data.pushmessage = rd["pushmesssage"].ToString();

                            PushMSGList.Add(Data);
                        }
                    }
                    rd.Close();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine ( "[ERROR] " + ex.Message );
            }
        }       
        private void ProcessBookedPUSHMSG()
        {
            if (PushMSGList.Count > 0)
            {
                bool bLoad = false;
                foreach (PUSHMSGInfo each in PushMSGList)
                {
                    if (each.deviceid.Equals("all") || each.deviceid.Equals("All") || each.deviceid.Equals("ALL") || each.deviceid.Equals("1")) //전체 푸쉬.
                    {
                        if (bLoad == false)
                            bLoad = LoadDeviceIDDB();
                        PluralPostData(each.type, each.pushmessage);
                    }
                    else //전체 아니니까 바로 푸쉬 해주도록 한다.
                    {
                        SinglePostData(each.deviceid, each.type, each.pushmessage);
                    }
                }
            }
        }
        private void SinglePostData(string deviceid, string type, string pushmessage)
        {
            string PostData = string.Empty;

            JsonObjectCollection totalCollection = new JsonObjectCollection();
            JsonObjectCollection Collection = new JsonObjectCollection("data");
            //JsonObjectCollection dryrunCollection = new JsonObjectCollection("dry_run");
            JsonArrayCollection arrayCollection = new JsonArrayCollection("registration_ids");

            arrayCollection.Add(new JsonStringValue(null, deviceid));
            Collection.Add(new JsonStringValue(type, pushmessage));

            totalCollection.Add(arrayCollection);
            totalCollection.Add(Collection);

            SendGCMNotification(API_KEY, totalCollection.ToString());
        }
        private void PluralPostData(string type, string message)
        {
            string postData = string.Empty;

            int count = DeviceIDList.Count;

            if (count > APPLY_COUNT)
            {
                int nCount = 0;

                JsonObjectCollection totalCollection = new JsonObjectCollection();
                JsonObjectCollection Collection = new JsonObjectCollection("data");
                JsonArrayCollection arrayCollection = new JsonArrayCollection("registration_ids");

                Collection.Add(new JsonStringValue("type", type));
                Collection.Add(new JsonStringValue("msg", message));

                foreach (string each in DeviceIDList)
                {
                    if (nCount > APPLY_COUNT)
                    {
                        totalCollection.Add(arrayCollection);
                        totalCollection.Add(Collection);

                        SendGCMNotification(API_KEY, totalCollection.ToString());

                        arrayCollection.Clear();
                        nCount = 0;
                    }
                    arrayCollection.Add(new JsonStringValue(null, each));
                    nCount++;
                }
                totalCollection.Add(arrayCollection);
                totalCollection.Add(Collection);

                SendGCMNotification(API_KEY, totalCollection.ToString());
            }
            else
            {
                JsonObjectCollection Collection = new JsonObjectCollection("data");
                JsonObjectCollection totalCollection = new JsonObjectCollection();
                JsonArrayCollection arrayCollection = new JsonArrayCollection("registration_ids");

                foreach (string each in DeviceIDList)
                {
                    arrayCollection.Add(new JsonStringValue(null, each));
                }

                Collection.Add(new JsonStringValue(type, message));
                totalCollection.Add(arrayCollection);
                totalCollection.Add(Collection);

                SendGCMNotification(API_KEY, totalCollection.ToString());
            }

            SendGCMNotification(API_KEY, postData);
        }
        public static bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        private string SendGCMNotification(string apiKey, string postData, string postDataContentType = "application/json")
        {
            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateServerCertificate);

            //
            //  MESSAGE CONTENT
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            //
            //  CREATE REQUEST
            HttpWebRequest Request = (HttpWebRequest)WebRequest.Create(strUri);
            Request.Method = "POST";
            Request.KeepAlive = false;
            Request.ContentType = postDataContentType;
            Request.Headers.Add(string.Format("Authorization: key={0}", apiKey));
            Request.ContentLength = byteArray.Length;

            Stream dataStream = Request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            //
            //  SEND MESSAGE
            try
            {
                WebResponse Response = Request.GetResponse();
                HttpStatusCode ResponseCode = ((HttpWebResponse)Response).StatusCode;
                if (ResponseCode.Equals(HttpStatusCode.Unauthorized) || ResponseCode.Equals(HttpStatusCode.Forbidden))
                {
                    Console.WriteLine("Unauthorized - need new token");                    
                }
                else if (!ResponseCode.Equals(HttpStatusCode.OK))
                {
                    Console.WriteLine("Response from web service isn't OK");                    
                }

                StreamReader Reader = new StreamReader(Response.GetResponseStream());
                string responseLine = Reader.ReadToEnd();
                Reader.Close();

                return responseLine;
            }
            catch (Exception ex)
            {
                Console.WriteLine ( "[ERROR] " + ex.Message );
            }
            return "error";
        }
        public void SendMessage(string message)
        {
            Random r = new Random();
            int sleep = r.Next(1, 5);
            Thread.Sleep(sleep * 1000);
            DateTime currTime = DateTime.Now;
            Console.WriteLine("[Send " + currTime.ToString("HH:mm:ss") + "] " + message + " Send!!");
        }        
    }
    class Sender
    {
        private string _sendMessage;
        private string _deviceid;
        private ManualResetEvent _doneEvent;
        public Sender(string deviceid, string message, ManualResetEvent doneEvent)
        {
            _deviceid = deviceid;
            _sendMessage = message;
            _doneEvent = doneEvent;
        }        
        public void ThreadPoolCallback(Object threadContext)
        {
            int threadIndex = (int)threadContext;
            Console.WriteLine("thread {0} start", threadIndex);
            SendMessage(_sendMessage);            
            //Random r = new Random();
            //int sleep = r.Next(1, 5);
            //Thread.Sleep(sleep * 1000);
            Console.WriteLine("thread {0} end", threadIndex);
            _doneEvent.Set();            
        }
        public void SendMessage(string message)
        {
            Console.WriteLine(message + " Send!!");
        }        
    }
}
