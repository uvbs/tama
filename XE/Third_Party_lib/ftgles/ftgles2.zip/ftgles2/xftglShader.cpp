#include <OpenGLES/ES2/gl.h>

namespace FTGL {
    const GLchar *xvShader_Color_Texture =
    #include "ftgles_vshader_color_texture.h"
    const GLchar *xfShader_Color_Texture =
    #include "ftgles_fshader_color_texture.h"
};