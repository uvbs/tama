#pragma once
namespace FTGL {
    extern const GLchar *xvShader_Color_Texture;
    extern const GLchar *xfShader_Color_Texture;
};

