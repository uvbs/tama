/*----------------------------------------------------------------------
Debugging Applications for Microsoft .NET and Microsoft Windows
Copyright � 1997-2003 John Robbins -- All rights reserved.
----------------------------------------------------------------------*/
#pragma once


#include <iostream>
#include <tchar.h>
#include <windows.h>
#include "BugslayerUtil.h"