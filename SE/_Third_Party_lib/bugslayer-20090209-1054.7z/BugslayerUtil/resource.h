//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BugslayerUtil.rc
//
#define IDD_ASSERTION                   101
#define IDS_NOSOUND                     1000
#define IDC_XICON                       1000
#define IDS_PLAYSOUND                   1000
#define IDC_ALWAYSWALKSTACK             1000
#define IDC_WALKALLTHREADSTACK          1000
#define IDS_LESS                        1001
#define IDC_EXPRESSIONS                 1001
#define IDC_PLAYSOUNDS                  1001
#define IDS_MORE                        1002
#define IDC_IGNOREONCE                  1002
#define IDC_FORCEONTOP                  1002
#define IDC_IGNOREALWAYS                1003
#define IDS_OPTIONS                     1003
#define IDC_WALKONLYACTIVE              1003
#define IDC_ABORTPROGRAM                1004
#define IDC_WALKNOTHREADS               1004
#define IDS_CENTERWINDOW                1004
#define IDC_BREAKINTODEBUGGER           1005
#define IDS_CREATEDUMPTITLE             1005
#define IDC_LESSMORE                    1006
#define IDS_PROMPTTEXT                  1006
#define IDC_DIVIDER                     1007
#define IDC_IGNOREGROUP                 1008
#define IDC_IGNORECOUNT                 1009
#define IDC_IGNORE_THIS                 1010
#define IDC_IGNORE_ALL                  1011
#define IDC_STACKGROUP                  1012
#define IDC_DOSTACKTRACE                1013
#define IDC_ALWAYSDOSTACK               1014
#define IDC_COPYTOCLIPBOARD             1014
#define IDC_STACKTRACE                  1015
#define IDC_THREADCOMBO                 1016
#define IDC_THREADSTATIC                1017
#define IDC_CREATEMINIDUMP              1018
#define IDC_DUMPNORMAL                  1019
#define IDC_DEPTHSTATIC                 1019
#define IDC_DUMPDATASEGS                1020
#define IDC_PROMPTTEXT                  1020
#define IDC_DEPTHCOMBO                  1020
#define IDC_DUMPFULL                    1021
#define IDC_EDITBOX                     1021
#define IDC_CREATEMINIDUMP2             1021
#define IDC_EMAILASSERT                 1021
#define IDC_DUMPHANDLE                  1022
#define IDC_CHECK1                      1022
#define IDC_SHOWARRAYSCHECK             1022
#define IDD_ASSERTOPTIONS               2000
#define IDD_INPUTBOX                    2001
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        2002
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
