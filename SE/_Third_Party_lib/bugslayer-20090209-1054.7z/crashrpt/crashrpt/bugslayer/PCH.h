/*----------------------------------------------------------------------
Debugging Applications for Microsoft .NET and Microsoft Windows
Copyright ?1997-2003 John Robbins -- All rights reserved.
----------------------------------------------------------------------*/

#define _WIN32_WINNT 0x502
#define WINVER 0x502

#include <windows.h>
#include <stdlib.h>
#include <tchar.h>
#include <PSAPI.h>
#include <process.h>
#include <malloc.h>
#include <mapi.h>

// Declare these so they are accessable anywhere in the project.
extern "C" void * _ReturnAddress ( void ) ;
#pragma intrinsic ( _ReturnAddress )

// Utilize the sexy (and safe!) string functions.
// Use the library.
#define STRSAFE_LIB
// Only use character count functions.
#define STRSAFE_NO_CB_FUNCTIONS
// STRSAFE came out long after I wrote this code.  Since it's working
// and heavily tested, I'll move the functions over as I can.  Hence, 
// I don't want to depreciate everything just yet.
#define STRSAFE_NO_DEPRECATE
#include <strsafe.h>

#include <crtdbg.h>
#define NEW_INLINE_WORKAROUND  new ( _NORMAL_BLOCK,\
                                     __FILE__ , __LINE__ )
#define new NEW_INLINE_WORKAROUND


#define BUGSUTIL_DLLINTERFACE

#define ASSERT( exp )
#define VERIFY( exp ) ((void)exp)
#define TRACE0(fmt)
#define TRACE1(fmt,arg1)
#define TRACE2(fmt,arg1,arg2)
#define TRACE3(fmt,arg1,arg2,arg3)
#define TRACE   __noop
