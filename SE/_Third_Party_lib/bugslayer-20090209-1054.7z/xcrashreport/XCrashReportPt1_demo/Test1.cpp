// Test1.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Test1.h"
#include "Test1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTest1App

BEGIN_MESSAGE_MAP(CTest1App, CWinApp)
	//{{AFX_MSG_MAP(CTest1App)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest1App construction

CTest1App::CTest1App()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTest1App object

CTest1App theApp;

/////////////////////////////////////////////////////////////////////////////
// CTest1App initialization

BOOL CTest1App::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CTest1Dlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	return FALSE;
}
