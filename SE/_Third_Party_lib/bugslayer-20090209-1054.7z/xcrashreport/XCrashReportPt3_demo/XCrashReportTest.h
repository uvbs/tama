// XCrashReportTest.h : main header file for the XCRASHREPORTTEST application
//

#ifndef XCRASHREPORTTEST_H
#define XCRASHREPORTTEST_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXCrashReportTestApp:
// See XCrashReportTest.cpp for the implementation of this class
//

class CXCrashReportTestApp : public CWinApp
{
public:
	CXCrashReportTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXCrashReportTestApp)
public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CXCrashReportTestApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif //XCRASHREPORTTEST_H
