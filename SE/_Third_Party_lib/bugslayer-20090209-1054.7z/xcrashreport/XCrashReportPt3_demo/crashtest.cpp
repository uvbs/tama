#include "windows.h"
#include "crashtest.h"
#include "FunctionStackTrace.h"

// Copyright � 1998 Bruce Dawson

// This source file causes a number of different crashes in order to exercise
// the exception handler.


// Disable the optimizer, otherwise it might 'fix' some of the 'bugs'
// that I've placed in my code for test purposes.
#pragma optimize("g", off)

typedef void (*tBogusFunction)();

void __cdecl CrashTestFunction(int nCrashCode)
{
	FUNCTION_STACK_TRACE("0001AAAA");

	char *p = 0;			// Null pointer.
	char x = 0;
	int y = 0;

	switch (nCrashCode)
	{
		default:
		case 0:				// Illegal write
			*p = x;	
			break;

		case 1:				// Illegal read
			x = *p;	
			break;

		case 2:				// Illegal read in C run time
			strcpy(0, 0);
			break;

		case 3:				// Illegal code read - jump to address zero
		{
			tBogusFunction	BadFunc = (tBogusFunction)0;
			BadFunc();
			break;
		}

		case 4:				// Divide by zero
			y = y / y;	
			break;
	}
}
