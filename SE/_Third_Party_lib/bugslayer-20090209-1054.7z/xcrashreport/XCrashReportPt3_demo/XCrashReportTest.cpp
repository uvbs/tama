// XCrashReportTest.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "XCrashReportTest.h"
#include "XCrashReportTestDlg.h"
#include <time.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CXCrashReportTestApp

BEGIN_MESSAGE_MAP(CXCrashReportTestApp, CWinApp)
	//{{AFX_MSG_MAP(CXCrashReportTestApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXCrashReportTestApp construction

CXCrashReportTestApp::CXCrashReportTestApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CXCrashReportTestApp object

CXCrashReportTestApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CXCrashReportTestApp initialization

BOOL CXCrashReportTestApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CXCrashReportTestDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	return FALSE;
}
