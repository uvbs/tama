// XCrashReportTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "XCrashReportTest.h"
#include "XCrashReportTestDlg.h"
#include "about.h"
#include "crashtest.h"
#include "CrashFileNames.h"
#include "FunctionStackTrace.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CXCrashReportTestDlg dialog

BEGIN_MESSAGE_MAP(CXCrashReportTestDlg, CDialog)
	//{{AFX_MSG_MAP(CXCrashReportTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(IDC_ERROR0, IDC_ERROR4, OnCrash)
END_MESSAGE_MAP()

CXCrashReportTestDlg::CXCrashReportTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CXCrashReportTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CXCrashReportTestDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CXCrashReportTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CXCrashReportTestDlg)
	DDX_Control(pDX, IDC_BANNER1, m_Banner1);
	DDX_Control(pDX, IDC_BANNER2, m_Banner2);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CXCrashReportTestDlg message handlers

BOOL CXCrashReportTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// create font for banner
	LOGFONT lf;
	CFont *pFont = NULL;
	pFont = m_Banner1.GetFont();
	pFont->GetLogFont(&lf);
	// increase size 
	lf.lfHeight = (lf.lfHeight > 0) ? lf.lfHeight+2 : lf.lfHeight-2;

	CString strBanner1 = 
			_T("Click on a button to cause this program to crash.  ");

	m_Banner1.SetTextColor(RGB(0,0,255), FALSE);
	m_Banner1.SetBackgroundColor(RGB(255,255,255), FALSE);
	m_Banner1.SetBold(TRUE, FALSE);
	m_Banner1.SetFont(&lf, FALSE);
	m_Banner1.SetMargins(20, 8);
	m_Banner1.SetWindowText(strBanner1);
	
	CString strBanner2 = _T("");
	strBanner2.Format(
			_T("Information about the crash will be written to the file ")
			_T("%s in this program's directory."),
			XCRASHREPORT_ERROR_LOG_FILE);

	m_Banner2.SetTextColor(RGB(0,0,255), FALSE);
	m_Banner2.SetBackgroundColor(RGB(255,255,255), FALSE);
	m_Banner2.SetFont(&lf, FALSE);
	m_Banner2.SetMargins(20, 8);
	m_Banner2.SetWindowText(strBanner2);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CXCrashReportTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CXCrashReportTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CXCrashReportTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CXCrashReportTestDlg::OnCrash(UINT nID)
{
	FUNCTION_STACK_TRACE("0002AAAA");
	int nCrashCode = nID - IDC_ERROR0;
	Crash1(nCrashCode);
}

void CXCrashReportTestDlg::Crash1(UINT nCrashCode)
{
	FUNCTION_STACK_TRACE("0002AAAB");
	Crash2(nCrashCode);
}

void CXCrashReportTestDlg::Crash2(UINT nCrashCode)
{
	FUNCTION_STACK_TRACE("0002AAAC");
	CrashTestFunction(nCrashCode);
}
