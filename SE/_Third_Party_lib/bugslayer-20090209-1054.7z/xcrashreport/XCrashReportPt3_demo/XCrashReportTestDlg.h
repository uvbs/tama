// XCrashReportTestDlg.h : header file
//

#ifndef XCRASHREPORTTESTDLG_H
#define XCRASHREPORTTESTDLG_H

#include "XColorStatic.h"

/////////////////////////////////////////////////////////////////////////////
// CXCrashReportTestDlg dialog

class CXCrashReportTestDlg : public CDialog
{
// Construction
public:
	CXCrashReportTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CXCrashReportTestDlg)
	enum { IDD = IDD_XCRASHREPORTTEST_DIALOG };
	CXColorStatic	m_Banner1;
	CXColorStatic	m_Banner2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXCrashReportTestDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	void Crash1(UINT nID);
	void Crash2(UINT nID);

	// Generated message map functions
	//{{AFX_MSG(CXCrashReportTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCrash(UINT nID);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif //XCRASHREPORTTESTDLG_H
