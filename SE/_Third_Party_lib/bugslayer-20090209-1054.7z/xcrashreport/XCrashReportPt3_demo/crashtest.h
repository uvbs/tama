#ifndef CRASHTEST_H
#define CRASHTEST_H

// Call this function if you want to test the exception handler by crashing.
// Pass any integer to specify a particular way of crashing.
void __cdecl CrashTestFunction(int nCrashCode);

#endif //CRASHTEST_H
