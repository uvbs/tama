README.txt for "tuxpaint-ttf-chinese-simplified"
Chinese (Simplified) TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

January 4, 2003 - June 5, 2004


This font is required to run Tux Paint in Chinese (Simplified).
(e.g., with the "--lang chinese" or "--lang simplified-chinese" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/
directory.

