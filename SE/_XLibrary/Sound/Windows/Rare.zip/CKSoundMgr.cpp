#include "stdafx.h"
#include <windows.h>
#include <assert.h>
#include <list>
#include "CKSoundMgr.h"


//------------------------------------------------------------------------------------------------------------
BOOL SetVolumeProfile(BOOL bMuteBGM,  int BGMVolume,  BOOL bMuteSound  ,int SndVolume);
BOOL GetVolumeProfile(BOOL &bMuteBGM, int &BGMVolume, BOOL &bMuteSound ,int &SndVolume);

//------------------------------------------------------------------------------------------------------------

CKSoundMgr::CKSoundMgr()
{
    m_Context = NULL;	
	m_Context = Rare_CreateContext();	
	/*
	if (m_Context == NULL) {
		::MessageBox(GetDesktopWindow(), "���� ��� ���� ����", "����", MB_OK);
	}
	*/

	m_BGMusic = NULL;
	memset(m_FileName, 0, sizeof(m_FileName) );

	if (GetVolumeProfile(m_bMuteBGM,m_BGMVolume,m_bMuteSound,m_SoundVolume) == FALSE)
	{
		m_bMuteBGM   = FALSE;
		m_bMuteSound = FALSE;
		m_BGMVolume = 255;
		m_SoundVolume = 255;
	}
}

//------------------------------------------------------------------------------------------------------------

CKSoundMgr::~CKSoundMgr()
{
	SetVolumeProfile(m_bMuteBGM, m_BGMVolume, m_bMuteSound, m_SoundVolume);

	RemoveAll();
    Rare_DestroyContext(m_Context);
	m_Context = NULL;
}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::OpenBGMusic(char *filename, BOOL repeat)
{	
	if(!m_Context)return;

	strcpy(m_FileName, filename);

	if (m_BGMusic != NULL) Rare_CloseSound(m_BGMusic);
    m_BGMusic = Rare_OpenSound(m_Context, filename);	

	Rare_SetRepeat(m_BGMusic, repeat);
	Rare_SetVolume(m_BGMusic, m_BGMVolume);
}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::SetBGMVolume(int volume)
{	
	if(!m_Context)return;

	m_BGMVolume = volume;
    Rare_SetVolume(m_BGMusic, m_BGMVolume);
}

//------------------------------------------------------------------------------------------------------------

int CKSoundMgr::GetBGMVolume()
{
    return m_BGMVolume;
}
    
//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::PlayBGMusic()
{	
	if(!m_Context)return;
	if (m_bMuteBGM == FALSE) Rare_PlaySound(m_BGMusic);	
}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::StopBGMusic()
{
	if(!m_Context)return;
    Rare_StopSound(m_BGMusic);
}

//------------------------------------------------------------------------------------------------------------

BOOL CKSoundMgr::IsBGMusic(RARESOUND sound)
{	
	if (m_BGMusic != NULL && sound == m_BGMusic) return TRUE;
	return FALSE;
}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::SetBGMMute(BOOL mute)
{
	m_bMuteBGM = mute;
	if (m_bMuteBGM == TRUE) StopBGMusic();
	else PlayBGMusic();
}

//------------------------------------------------------------------------------------------------------------

BOOL CKSoundMgr::GetBGMMute()
{
	return m_bMuteBGM;
}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::SetSoundMute(BOOL mute)
{
	m_bMuteSound = mute;
}

//------------------------------------------------------------------------------------------------------------

BOOL CKSoundMgr::GetSoundMute()
{
	return m_bMuteSound;
}
//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::SetSoundVolume(int volume)
{
    m_SoundVolume = volume;
}

//------------------------------------------------------------------------------------------------------------

int CKSoundMgr::GetSoundVolume()
{
    return m_SoundVolume;
}

//------------------------------------------------------------------------------------------------------------

BOOL CKSoundMgr::OpenSound(int FileID)
{	
	if (m_Context == NULL) return FALSE;

	//�ߺ� �ε������� �˻� 
	Sound_Itor it = m_SoundList.begin();
	while(it != m_SoundList.end())
	{
	    if ( (*it)->FileID == FileID)
		{
			return FALSE;
		}
		it++;
	}

	//�ε��ؼ� ����Ʈ�� �߰� 
    ST_SOUND *pSound;
	pSound = new ST_SOUND;

	pSound->Sound = NULL;
	char filename[100];
	sprintf(filename, "Snd/%04d.snd", FileID);

	pSound->Sound = Rare_OpenSound(m_Context, filename, RARE_OPENEFFECT);
	if (pSound->Sound != NULL) {
		pSound->FileID = FileID;
	    pSound->Use  =  1;
		m_SoundList.push_back(pSound);
		return TRUE;
	}
	if (pSound != NULL) delete pSound;

	return FALSE;
}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::CloseSound(int FileID)
{
	if (m_Context == NULL) return;

    ST_SOUND *pSound;
	pSound = NULL;
    Sound_Itor it = m_SoundList.begin();
	while(it != m_SoundList.end()) {
	    if ((*it)->FileID == FileID) {
		    pSound = (*it);
		    break;
		}
		it++;
	}	
	if (pSound != NULL) {
		m_SoundList.erase(it);
		Rare_CloseSound(pSound->Sound);
		delete pSound;
		pSound = NULL;
	}

}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::PlaySound(int FileID)
{	
	if (m_Context == NULL) return;
	if (m_bMuteSound) return;

	Sound_Itor it = m_SoundList.begin();
	while(it != m_SoundList.end()) {
	    if ((*it)->FileID == FileID)
		{		    
			Rare_SetVolume((*it)->Sound,m_SoundVolume);
		    Rare_PlaySound((*it)->Sound);			
			break;
		}
		it++;
	}

}

//------------------------------------------------------------------------------------------------------------

void CKSoundMgr::RemoveAll()
{	
   if (m_Context == NULL) return;
   
   ST_SOUND *pSound;
   pSound = NULL;
   for(Sound_Itor itor = m_SoundList.begin(); itor != m_SoundList.end(); ++itor )
   {
     pSound = (*itor);
	 if (pSound != NULL) {
		 Rare_CloseSound(pSound->Sound);
		 delete pSound;
		 pSound = NULL;
	 }
   }
   m_SoundList.clear();
}

//------------------------------------------------------------------------------------------------------------

BOOL SetVolumeProfile(BOOL bMuteBGM,  int BGMVolume,  BOOL bMuteSound  ,int SndVolume)
{
	return FALSE;  //TODO : ���� ���Ǳ� ���� 

}

//------------------------------------------------------------------------------------------------------------

BOOL GetVolumeProfile(BOOL &bMuteBGM, int &BGMVolume, BOOL &bMuteSound ,int &SndVolume)
{
	return FALSE;  //TODO : ���� ���Ǳ� �ҷ����� 

}

//------------------------------------------------------------------------------------------------------------