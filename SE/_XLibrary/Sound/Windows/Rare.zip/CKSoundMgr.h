#ifndef CKSOUNDMGR
#define CKSOUNDMGR

#include "Rare.h"


//
typedef struct 
{
    int FileID;
    RARESOUND Sound;
    int Use;
	
}ST_SOUND;

//
using namespace std;

typedef list<ST_SOUND*>           Sound_List;
typedef list<ST_SOUND*>::iterator Sound_Itor;


//
class CKSoundMgr
{

public:
    RARECONTEXT m_Context;
    RARESOUND   m_BGMusic;
	char        m_FileName[255];

	BOOL        m_bMuteBGM;
    int         m_BGMVolume;

    Sound_List  m_SoundList;
	int         m_SoundVolume;
	BOOL        m_bMuteSound;



public:
    CKSoundMgr();
    virtual ~CKSoundMgr();

    // Background Music
    void OpenBGMusic(char *filename, BOOL repeat = TRUE);
    void SetBGMVolume(int volume);
    int  GetBGMVolume();
    void PlayBGMusic();
    void StopBGMusic();
	BOOL IsBGMusic(RARESOUND sound);

	void SetBGMMute(BOOL mute);
	BOOL GetBGMMute();

    // Effect sound
	void SetSoundVolume(int volume);
	int  GetSoundVolume();
	void SetSoundMute(BOOL mute);
    BOOL GetSoundMute();
    BOOL OpenSound(int FileID);
	void CloseSound(int FileID);
	void PlaySound(int FileID);

	void RemoveAll();
};


#endif

//------------------------------------------------------------------------------------------------------------
